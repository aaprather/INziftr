Thanks for using this software!

INziftr is coded in C# and provides an easy to use GUI for pooler's CPUminer.

The CPUminer files are downloaded into a folder named 'temp_folder' in the directory that INziftr.exe is in.

If you have any suggestions for a future program feel free to send me a message on sourceforge or github /aaprather1



-enjoy